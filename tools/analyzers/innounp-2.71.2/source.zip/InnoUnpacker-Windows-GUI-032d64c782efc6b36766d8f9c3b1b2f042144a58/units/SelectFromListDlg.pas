(* Delphi Dialog
   Auswahl und Bearbeiten von Listeneintr�gen
   ==========================================
   
   � Dr. J. Rathlev, D-24222 Schwentinental (kontakt(a)rathlev-home.de)

   The contents of this file may be used under the terms of the
   Mozilla Public License ("MPL") or
   GNU Lesser General Public License Version 2 or later (the "LGPL")

   Software distributed under this License is distributed on an "AS IS" basis,
   WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
   the specific language governing rights and limitations under the License.
    
   Vers. 1 - Apr. 2005
   Vers. 2 - July 2022: define compiler switch "ACCESSIBLE" to make the
                        messages accessible to screenreaders
   last modified: July 2025
    *)
    
unit SelectFromListDlg;

interface

uses Winapi.Windows, System.SysUtils, System.Classes, Vcl.Graphics, Vcl.Forms,
  Vcl.Controls, Vcl.StdCtrls, Vcl.Buttons, Vcl.ExtCtrls, StringUtils;

type
  TCheckEntry = function (const AText : string) : boolean of object;

  TSelectOption = (soPrompt,soEdit,soOrder,soMulti,soDelAll,soNoConfirm);
  TSelectOptions = set of TSelectOption;

  TSelectFromListDialog = class(TForm)
    OKBtn: TBitBtn;
    CancelBtn: TBitBtn;
    lbxStringList: TListBox;
    gbxEdit: TGroupBox;
    btnInsert: TBitBtn;
    btnDelete: TBitBtn;
    btnEdit: TBitBtn;
    gbxMove: TGroupBox;
    btnDefault: TBitBtn;
    paEdit: TPanel;
    paList: TPanel;
    btnPrompt: TBitBtn;
    UpBtn: TBitBtn;
    DownBtn: TBitBtn;
    lbHint: TStaticText;
    lbDesc: TStaticText;
    btnDelAll: TBitBtn;
    procedure btnInsertClick(Sender: TObject);
    procedure btnDeleteClick(Sender: TObject);
    procedure btnEditClick(Sender: TObject);
    procedure lbxStringListDblClick(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure UpBtnClick(Sender: TObject);
    procedure DownBtnClick(Sender: TObject);
    procedure btnDefaultClick(Sender: TObject);
    procedure btnPromptClick(Sender: TObject);
    procedure FormKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
    procedure btnDelAllClick(Sender: TObject);
    procedure FormAfterMonitorDpiChanged(Sender: TObject; OldDPI,
      NewDPI: Integer);
    procedure FormShow(Sender: TObject);
  private
    { Private declarations }
    FEdit   : boolean;
    dist,hh : integer;
    FNoConfirm : boolean;
    FText,
    DefDelimitedText : string;
    FCheckEntry : TCheckEntry;
    function DialogPos(Sender: TObject) : TPoint;
  public
    { Public declarations }
{$IFDEF HDPI}   // scale glyphs and images for High DPI
    procedure AfterConstruction; override;
{$EndIf}
    function Execute (APos : TPoint; Titel,Desc,Hint : string;
                      Options : TSelectOptions; ACols : integer;
                      Convert : TTextChange; const Default : string;
                      SList : TStrings; var AText : string;
                      ShowCancel : boolean = true; CheckEntry : TCheckEntry = nil) : TModalResult;  overload;
    function Select (APos : TPoint; Titel,Desc,Hint : string;
                     Options : TSelectOptions; ACols : integer;
                     Convert : TTextChange; const Default : string;
                     SList : TStrings; var AText : string;
                     ShowCancel : boolean = true; CheckEntry : TCheckEntry = nil) : boolean;  overload;
    function Select (APos : TPoint; Titel,Desc,Hint : string;
                     ACols : integer;
                     Convert : TTextChange; const Default : string;
                     var ListText : string;
                     ADel : Char = ','; AQuote : Char ='"') : boolean; overload;
    function Select (APos : TPoint; Titel,Desc,Hint : string; Prompt : boolean;
                     SList : TStrings; var AText  : string) : TModalResult; overload;
    procedure Show (APos : TPoint; Titel,Desc,Hint : string;
                    ACols : integer; SList : TStrings);
  end;

function EditList (APos : TPoint; const Titel,Desc,Hint : string;
                   Options : TSelectOptions; ACols : integer;
                   Convert : TTextChange; const Default : string;
                   SList : TStrings; var AText  : string) : boolean;

function SelectFromList (APos : TPoint; const Titel,Desc,Hint : string; Prompt : boolean;
                    SList : TStrings; var AText  : string) : boolean;

var
  SelectFromListDialog: TSelectFromListDialog;

implementation

{$R *.DFM}

uses Vcl.Dialogs, GnuGetText, WinUtils, InputString,
   {$IFDEF ACCESSIBLE} ShowMessageDlg {$ELSE} MsgDialogs {$ENDIF};

{------------------------------------------------------------------- }
procedure TSelectFromListDialog.FormCreate(Sender: TObject);
begin
  TranslateComponent (self,'dialogs');
  FCheckEntry:=nil; dist:=5; hh:=lbHint.Height;
  lbHint.Width:=gbxEdit.Width;
  end;

procedure TSelectFromListDialog.FormKeyDown(Sender: TObject; var Key: Word;
  Shift: TShiftState);
begin
{$IFDEF ACCESSIBLE}
  if (Key=VK_F11) then begin
    with ActiveControl do if length(Hint)>0 then ShowHintInfo(Hint);
    end;
{$ENDIF}
end;

procedure TSelectFromListDialog.FormShow(Sender: TObject);
begin
  FitToScreen(Screen,self);
  end;

procedure TSelectFromListDialog.FormAfterMonitorDpiChanged(Sender: TObject;
  OldDPI, NewDPI: Integer);
begin
  dist:=MulDiv(dist,NewDpi,OldDPI);
  hh:=MulDiv(hh,NewDpi,OldDPI);
  end;

{$IFDEF HDPI}   // scale glyphs and images for High DPI
procedure TSelectFromListDialog.AfterConstruction;
begin
  inherited;
  if Application.Tag=0 then
    ScaleButtonGlyphs(self,PixelsPerInchOnDesign,Monitor.PixelsPerInch);
  end;
{$EndIf}

function TSelectFromListDialog.DialogPos(Sender: TObject) : TPoint;
begin
  Result:=BottomLeftPos((Sender as TControl),Point(-100,10));
  end;

procedure TSelectFromListDialog.btnInsertClick(Sender: TObject);
var
  s  : string;
  ok : boolean;
begin
  s:='';
  if InputText(DialogPos(Sender),dgettext('dialogs','Add item'),lbDesc.Caption,s) then begin
    if assigned(FCheckEntry) then ok:=FCheckEntry(s) else ok:=true;
    if ok then with lbxStringList do ItemIndex:=Items.Add(s)
    else ErrorDialog(CursorPos,SafeFormat(dgettext('dialogs','Invalid entry: "%s"'),[s]));
    end;
  end;

procedure TSelectFromListDialog.btnDelAllClick(Sender: TObject);
begin
  if FNoConfirm or ConfirmDialog(DialogPos(Sender),dgettext('dialogs','Clear whole list')+'?') then
    lbxStringList.Clear;
  end;

procedure TSelectFromListDialog.btnDeleteClick(Sender: TObject);
var
  s : string;
  n : integer;
begin
  with lbxStringList do if Multiselect then begin
    if FNoConfirm or ConfirmDialog (DialogPos(Sender),dgettext('dialogs','Remove all selected items?')) then begin
      for n:=Items.Count-1 downto 0 do if Selected[n] then Items.Delete(n);
      end
    end
  else if ItemIndex>=0 then begin
    s:=Items[ItemIndex];
    if FNoConfirm or ConfirmDialog (DialogPos(Sender),SafeFormat(dgettext('dialogs','Remove item: "%s"?'),[s])) then begin
      n:=ItemIndex;
      Items.Delete(ItemIndex);
      if n>Items.Count then ItemIndex:=Items.Count-1 else ItemIndex:=n;
      end;
    end;
  end;

procedure TSelectFromListDialog.btnEditClick(Sender: TObject);
var
  s  : string;
  ok : boolean;
begin
  with lbxStringList do if ItemIndex>=0 then begin
    s:=Items[ItemIndex];
    if InputText(DialogPos(Sender),dgettext('dialogs','Edit item'),lbDesc.Caption,s) then begin
      if assigned(FCheckEntry) then ok:=FCheckEntry(s) else ok:=true;
      if ok then Items[ItemIndex]:=s
      else ErrorDialog(CursorPos,SafeFormat(dgettext('dialogs','Invalid entry: "%s"'),[s]));
      end;
    end;
  end;

procedure TSelectFromListDialog.btnDefaultClick(Sender: TObject);
begin
  if FNoConfirm or ConfirmDialog(DialogPos(Sender),dgettext('dialogs','Reset to default values')+'?') then with lbxStringList do begin
    Clear;
    Items.DelimitedText:=DefDelimitedText;
    end;
  end;

procedure TSelectFromListDialog.lbxStringListDblClick(Sender: TObject);
var
  s : string;
begin
  if FEdit then begin
    with lbxStringList do if ItemIndex>=0 then begin
      s:=Items[ItemIndex];
      if InputText(CursorPos(Point(-20,20)),dgettext('dialogs','Edit item'),lbDesc.Caption,s) then Items[ItemIndex]:=s;
      end
    end
  else ModalResult:=mrOK;
  end;

procedure TSelectFromListDialog.btnPromptClick(Sender: TObject);
//var
//  ok : boolean;
begin
  ModalResult:=mrYes;
  end;

{------------------------------------------------------------------- }
procedure TSelectFromListDialog.UpBtnClick(Sender: TObject);
var
  n : integer;
begin
  with lbxStringList do if (Count>0) and (ItemIndex>0) then begin
    n:=ItemIndex;
    Items.Exchange(n,n-1);
    ItemIndex:=n-1;
    end;
  end;

procedure TSelectFromListDialog.DownBtnClick(Sender: TObject);
var
  n : integer;
begin
  with lbxStringList do if (Count>0) and (ItemIndex<Count-1) then begin
    n:=ItemIndex;
    Items.Exchange(n,n+1);
    ItemIndex:=n+1;
    end;
  end;

{------------------------------------------------------------------- }
function TSelectFromListDialog.Execute (APos : TPoint; Titel,Desc,Hint : string;
                    Options : TSelectOptions; ACols : integer;
                    Convert : TTextChange; const Default : string;
                    SList : TStrings; var AText : string;
                    ShowCancel : boolean = true; CheckEntry : TCheckEntry = nil) : TModalResult;
var
  i,h,hg,d : integer;
begin
  AdjustFormPosition(Screen,self,APos);
  Caption:=Titel;
  CancelBtn.Visible:=ShowCancel;
  FCheckEntry:=CheckEntry;
  FText:=''; h:=gbxEdit.Top;
  lbDesc.Caption:=Desc;
  with lbHint do begin
    Caption:=Hint; TabStop:=length(Hint)>0;
    end;
  FEdit:=soEdit in Options;
  btnPrompt.Visible:=soPrompt in Options;
  FNoConfirm:=soNoConfirm in Options;
  gbxEdit.Visible:=FEdit;
  gbxMove.Visible:=soOrder in Options;
  if length(Default)>0 then begin
    btnDefault.Show;
    with btnDefault do hg:=Top+Height+dist;
    end
  else begin
    btnDefault.Hide;
    with btnEdit do hg:=Top+Height+dist;
    end;
  if soDelAll in Options then begin
    btnDelAll.Show;
    with btnDelAll do begin
      Top:=hg;
      inc(hg,Height+2*dist);
      end;
    end
  else btnDelAll.Hide;
  inc(h,hg+2*dist);
  with gbxEdit do begin
    Height:=hg;
    gbxMove.Top:=Top+Height+dist;
    end;
  d:=2*dist;
  with gbxMove do if Visible then begin
    lbHint.Top:=Top+Height+d;
    inc(h,gbxMove.Height+d);
    end
  else lbHint.Top:=Top;
  inc(h,hh);
  with btnPrompt do if Visible then inc(h,Height+d);
  ClientHeight:=h+2*OKBtn.Height+d;
  with lbHint do Anchors:=Anchors+[akBottom];
  DefDelimitedText:=Default;
  with lbxStringList do begin
//    Items.Delimiter:=SList.Delimiter;
//    Items.QuoteChar:=SList.QuoteChar;
//    Items:=SList;
    Hint:=Desc;
    Items.Assign(SList);
    Columns:=ACols;
    ExtendedSelect:=soMulti in Options;
    MultiSelect:=ExtendedSelect;
    ItemIndex:=Items.IndexOf(AText);
    end;
  Result:=ShowModal;
  if Result<>mrCancel then with lbxStringList do begin
    if Convert<>tcNone then with Items do begin
      for i:=0 to Count-1 do Strings[i]:=TextChangeCase(Strings[i],Convert);
      end;
    if FEdit then SList.Assign(Items); // .DelimitedText:=Items.DelimitedText;
    if ItemIndex>=0 then begin
      if soMulti in Options then begin
        AText:='';
        for i:=0 to Items.Count-1 do if Selected[i] then AText:=AText+Items[i]+'|';
        delete(AText,length(Atext),1);
        end
      else AText:=Items[ItemIndex]
      end
    else AText:='';
    end
  end;

function TSelectFromListDialog.Select(APos : TPoint; Titel,Desc,Hint : string;
                    Options : TSelectOptions; ACols : integer;
                    Convert : TTextChange; const Default : string;
                    SList : TStrings; var AText : string;
                    ShowCancel : boolean = true; CheckEntry : TCheckEntry = nil) : boolean;
begin
  Result:=Execute(APos,Titel,Desc,Hint,Options,ACols,tcNone,Default,SList,AText,ShowCancel,CheckEntry)<>mrCancel;
  end;

function TSelectFromListDialog.Select(APos : TPoint; Titel,Desc,Hint : string;
                    ACols : integer; Convert : TTextChange; const Default : string;
                    var ListText : string;
                    ADel : Char = ','; AQuote : Char ='"') : boolean;
var
  sl : TStringList;
  s  : string;
begin
  sl:=TStringList.Create;
  with sl do begin
    Sorted:=true; Delimiter:=ADel; QuoteChar:=AQuote;
    DelimitedText:=ListText;
    end;
  Result:=Select(APos,Titel,Desc,Hint,[],ACols,tcNone,Default,sl,s,true);
  ListText:=sl.DelimitedText;
  sl.Free;
  end;

function TSelectFromListDialog.Select (APos : TPoint; Titel,Desc,Hint : string; Prompt : boolean;
                    SList : TStrings; var AText  : string) : TModalResult;
var
  so : TSelectOptions;
begin
  if Prompt then so:=[soPrompt] else so:=[];
  Result:=SelectFromListDialog.Execute(APos,Titel,Desc,Hint,so,0,
                                       tcNone,'',SList,AText);
  end;

procedure TSelectFromListDialog.Show (APos : TPoint; Titel,Desc,Hint : string;
                                      ACols : integer; SList : TStrings);
var
  s : string;
begin
  Execute(APos,Titel,Desc,Hint,[],ACols,tcNone,'',SList,s,false);
  end;

{------------------------------------------------------------------- }
function EditList (APos : TPoint; const Titel,Desc,Hint : string;
                   Options : TSelectOptions; ACols : integer;
                   Convert : TTextChange; const Default : string;
                   SList : TStrings; var AText  : string) : boolean;
begin
  if not assigned(SelectFromListDialog) then
    SelectFromListDialog:=TSelectFromListDialog.Create(Application);
  Result:=SelectFromListDialog.Select(APos,Titel,Desc,Hint,Options,ACols,
                                       Convert,Default,SList,AText);
  FreeAndNil(SelectFromListDialog)
  end;

function SelectFromList (APos : TPoint; const Titel,Desc,Hint : string; Prompt : boolean;
                    SList : TStrings; var AText  : string) : boolean;
var
  so : TSelectOptions;
begin
  if not assigned(SelectFromListDialog) then
    SelectFromListDialog:=TSelectFromListDialog.Create(Application);
  if Prompt then so:=[soPrompt] else so:=[];
  Result:=SelectFromListDialog.Select(APos,Titel,Desc,Hint,so,0,
                                       tcNone,'',SList,AText);
  FreeAndNil(SelectFromListDialog)
  end;

end.
