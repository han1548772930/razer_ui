(* Unpacker for Inno setup files
   =============================
   Windows GUI for "innounp.exe"
   see: https://sourceforge.net/projects/innounp/files/
   and https://github.com/jrathlev/InnoUnpacker-Windows-GUI

   � Dr. J. Rathlev, D-24222 Schwentinental (kontakt(a)rathlev-home.de)

   The contents of this file may be used under the terms of the
   Mozilla Public License ("MPL") or
   GNU Lesser General Public License Version 2 or later (the "LGPL")

   Software distributed under this License is distributed on an "AS IS" basis,
   WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
   the specific language governing rights and limitations under the License.

   J. Rathlev, Jan. 2008
   Vers. 1.6   (August 2020):   added filter to extract single files
   Vers. 1.7   (October 2021):  onsole output uses UTF8
   Vers. 1.8   (June 2022):     "embedded option" added
   Vers. 1.9.1 (August 2022):   command line options added
   Vers. 1.9.4 (August 2024):   innounp updated to version 1.72
                                timeout on calling innounp.exe with confirmation
   Vers. 1.9.6 (October 2024):  using innounp up to version 0.50 and 1.75
   Vers. 2.0   (December 2024): new layout,
                                colored display of innounp (v1.77 and up) output
   Vers. 2.1   (November 2025): extract selected files (requires innounp v2.65.4 and up)
   Vers. 2.2   (January 2026);  user selectable language

   last modified: July 2026

   Command line options: [<setupname>] [options]
     <setupname>  : name of setup file to be unpacked
     /d:<destdir> : destination directory for unpacked files
     /f:<filter>  : file filter
     /e:<pwd>     : encryption password
     /c           : only files from {app} path
     /m           : process internal embedded files
     /s           : extract files without paths
     /a           : process all copies of duplicate files
     /o           : overwrite files
     /p           : run as portable program
     /k           : run in dark mode
   *)

unit UnpackMain;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes,
  Vcl.Graphics, Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.StdCtrls, Vcl.Buttons,
  Vcl.ExtCtrls, WinApiUtils, Vcl.ComCtrls, Vcl.Menus, LangUtils,
  System.ImageList, Vcl.ImgList, StyleUtils;

const
  ProgName = 'InnoUnpacker';
  ProgVers = ' 2.2.12';
  CopRgt = '� 2014-2026 Dr. J. Rathlev, D-24222 Schwentinental';
  EmailAdr = 'kontakt@rathlev-home.de';

  defPipeSize = 1024*1024;

type
  TViewMode = (vmNone,vmInfo,vmList,vmLang,vmVersion,vmVerify,vmExtract);

  TMainForm = class(TForm)
    pnTop: TPanel;
    Label2: TLabel;
    cbFile: TComboBox;
    bbOptions: TBitBtn;
    bbExit: TBitBtn;
    bbList: TBitBtn;
    OpenDialog: TOpenDialog;
    bbExtract: TBitBtn;
    bbVerify: TBitBtn;
    pnExtract: TPanel;
    cbDir: TComboBox;
    Label1: TLabel;
    bbStart: TBitBtn;
    cxDupl: TCheckBox;
    cxOverwrite: TCheckBox;
    cxStrip: TCheckBox;
    bbCopyResult: TBitBtn;
    Label3: TLabel;
    cbFilter: TComboBox;
    bbFilter: TBitBtn;
    bbDir: TBitBtn;
    bbFile: TBitBtn;
    cxEmbedded: TCheckBox;
    bbDown: TBitBtn;
    bbUp: TBitBtn;
    bbInfo: TBitBtn;
    cxEncrypted: TCheckBox;
    edPassword: TLabeledEdit;
    pnBottom: TPanel;
    pnTools: TPanel;
    bbVersion: TBitBtn;
    bbCopyPath: TBitBtn;
    bbLang: TBitBtn;
    bbScript: TBitBtn;
    bbSetupInfo: TBitBtn;
    paShowText: TPanel;
    pbShowText: TPaintBox;
    sbVert: TScrollBar;
    sbHorz: TScrollBar;
    cxOnlyApp: TCheckBox;
    bbSelFiles: TBitBtn;
    rgEncoding: TRadioGroup;
    pmMain: TPopupMenu;
    pmiLanguage: TMenuItem;
    pmiAbout: TMenuItem;
    ilStat: TImageList;
    N1: TMenuItem;
    pmiDisplay: TMenuItem;
    pmiDmDefault: TMenuItem;
    pmiDmLight: TMenuItem;
    pmiDmDark: TMenuItem;
    pmiReginal: TMenuItem;
    pmiInternational: TMenuItem;
    pmiLocalized: TMenuItem;
    procedure FormCreate(Sender: TObject);
    procedure pmiInfoClick(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure FormShow(Sender: TObject);
    procedure bbOptionsClick(Sender: TObject);
    procedure bbExitClick(Sender: TObject);
    procedure bbListClick(Sender: TObject);
    procedure bbFileClick(Sender: TObject);
    procedure bbVerifyClick(Sender: TObject);
    procedure bbExtractClick(Sender: TObject);
    procedure bbDirClick(Sender: TObject);
    procedure cbDirExit(Sender: TObject);
    procedure bbStartClick(Sender: TObject);
    procedure cbFileCloseUp(Sender: TObject);
    procedure cbDirCloseUp(Sender: TObject);
    procedure bbCopyResultClick(Sender: TObject);
    procedure bbFilterClick(Sender: TObject);
    procedure cbFilterCloseUp(Sender: TObject);
    procedure bbUpClick(Sender: TObject);
    procedure bbDownClick(Sender: TObject);
    procedure cxEncryptedClick(Sender: TObject);
    procedure bbVersionClick(Sender: TObject);
    procedure bbCopyPathClick(Sender: TObject);
    procedure FormResize(Sender: TObject);
    procedure bbLangClick(Sender: TObject);
    procedure bbScriptClick(Sender: TObject);
    procedure bbSetupInfoClick(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure pbShowTextPaint(Sender: TObject);
    procedure sbVertScroll(Sender: TObject; ScrollCode: TScrollCode;
      var ScrollPos: Integer);
    procedure FormMouseWheel(Sender: TObject; Shift: TShiftState;
      WheelDelta: Integer; MousePos: TPoint; var Handled: Boolean);
    procedure edPasswordKeyDown(Sender: TObject; var Key: Word;
      Shift: TShiftState);
    procedure bbSelFilesClick(Sender: TObject);
    procedure cxEmbeddedClick(Sender: TObject);
    procedure bbInfoClick(Sender: TObject);
    procedure SetLanguageClick(Sender : TObject; const Language : TLangCodeString);
    procedure pmiDmDefaultClick(Sender: TObject);
    procedure pmiDmLightClick(Sender: TObject);
    procedure pmiDmDarkClick(Sender: TObject);
    procedure pmiInternationalClick(Sender: TObject);
    procedure pmiLocalizedClick(Sender: TObject);
  private
    { Private-Deklarationen }
    AppPath,UserPath,
    IniName,ProgPath,
    ProgVersName,ProgVersDate,
    UnpProg,UnpVersion,
    TempFile,SelFilesHint : string;
    SelectedFiles,
    ConsoleText           : TStringList;
    UseReg,Ready,
    NewUnp,CanList,
    UseFilelist    : boolean;
    LineHeight,VisibleLines,
    TextWdt,CtHd          : integer;
    DisplayMode           : TDisplayMode;
    ViewMode              : TViewMode;
    Languages             : TLanguageList;
    mp                    : TRect;
    procedure ChangeStyle (dm : TDisplayMode);
    procedure UpdateView;
    procedure UpdateShowText (GoBottom : boolean);
    function StripColCtrls (const AText : string) : string;
    function LoadUnpacker : boolean;
    procedure CheckUnpackVersion;
    function IsUnicodeSetup : boolean;
    procedure ExtractFiles (const Filter : string);
    procedure ShowUnpackInfo (const Command,FileName,Filter,Comment : string; GoBottom : boolean = false);
    function Execute (const Command : string; OutText: TStringList = nil) : boolean;
    procedure WMDROPFILES (var Msg: TMessage); message WM_DROPFILES;
  public
    { Public-Deklarationen }
  end;

var
  MainForm: TMainForm;

implementation

{$R *.dfm}

uses System.IniFiles, System.StrUtils, Winapi.ShellApi, System.UITypes, Vcl.ClipBrd,
  Vcl.Themes, System.Math, GnuGetText, InitProg, WinUtils, MsgDialogs, IniFileUtils, PathUtils,
  ListUtils, WinDevUtils, StringUtils, ShellDirDlg, SelectFromListDlg,
  SelectListItems;

{ ------------------------------------------------------------------- }
resourcestring
  rsInfo = 'Command line options: [<name>] [options]'+sLineBreak+
     #9'<name>'#9#9': name of setup file to be unpacked'+sLineBreak+
     #9'/d:<ddir>'#9': destination directory for unpacked files'+sLineBreak+
     #9'/f:<filter>'#9': file filter'+sLineBreak+
     #9'/e:<pwd>'#9': encryption password'+sLineBreak+
     #9'/l:<la>'#9#9': language selection (en, de, fr, it or hu)'+sLineBreak+
     #9'/m'#9#9': process internal embedded files'+sLineBreak+
     #9'/s'#9#9': extract files without paths'+sLineBreak+
     #9'/a'#9#9': process all copies of duplicate files'+sLineBreak+
     #9'/o'#9#9': overwrite files'+sLineBreak+
     #9'/p'#9#9': run as portable program'+sLineBreak+
     #9'/k'#9#9': run in dark mode';

const
  mList = 20;
  IniExt = 'ini';
  InnoUnp = 'innounp.exe';

  (* INI-Sektionen *)
  CfGSekt = 'Config';
  FileSekt = 'Files';
  DirSekt  = 'Directories';
  FilterSekt = 'Filter';
  SelectSekt = 'SelectedFiles';

  (* INI-Variablen *)
  iniLeft = 'Left';
  iniTop  = 'Top';
  iniWdt  = 'Width';
  iniHgt  = 'Height';
  IniDispMode = 'DisplayMode';
  IniRegional = 'Regional';
  iniUnp = 'Unpacker';
  iniFName = 'Name';
  iniFileList = 'UseFilelist';

//  DarkStyle = 'Windows10 Dark';
  LightStyle = 'Windows10';
  DarkStyle = 'JR Dark';

procedure TMainForm.FormCreate(Sender: TObject);
var
  i : integer;
  port,UseDarkMode : boolean;
  s,sa,sd,sf : string;
begin
  TranslateComponent(self);
  DragAcceptFiles(MainForm.Handle, true);
  InitPaths(AppPath,UserPath,ProgPath);
  InitVersion(ProgName,ProgVers,CopRgt,3,3,ProgVersName,ProgVersDate);
  port:=false; sd:=''; sf:=''; sa:=''; UseFilelist:=false; UseDarkMode:=false;
  if ParamCount>0 then for i:=1 to ParamCount do begin
    s:=ParamStr(i);
    if (s[1]='/') or (s[1]='-') then begin
      Delete(s,1,1);
      if CompareOption(s,'k') then UseDarkMode:=true
      else if CompareOption(s,'m') then cxEmbedded.Checked:=true
      else if CompareOption(s,'c') then cxOnlyApp.Checked:=true
      else if CompareOption(s,'s') then cxStrip.Checked:=true
      else if CompareOption(s,'a') then cxDupl.Checked:=true
      else if CompareOption(s,'o') then cxOverwrite.Checked:=true
      else if CompareOption(s,'p') then port:=true
      else if ReadOptionValue(s,'w') then edPassword.Text:=s
      else if ReadOptionValue(s,'d') then sd:=s
      else if ReadOptionValue(s,'f') then sf:=s;
      cxEncrypted.Checked:=length(edPassword.Text)>0;
      end
    else sa:=s;
    end;
  if port or IsEmptyStr(AppPath) or IsRemovableDrive(PrgPath) then s:=PrgPath else s:=AppPath;
  Languages:=TLanguageList.Create(PrgPath);
  with Languages do begin
    Menu:=pmiLanguage;
    LoadLanguageNames(SelectedLanguage);
    OnLanguageItemClick:=SetLanguageClick;
    end;
  IniName:=Erweiter(s,PrgName,IniExt);
  with TUnicodeIniFile.CreateForRead(IniName) do begin
    with mp do begin
      Left:=ReadInteger(CfgSekt,iniLeft,Left);
      Top:=ReadInteger(CfgSekt,iniTop,Top);
      Width:=ReadInteger(CfgSekt,iniWdt,ClientWidth);
      Height:=ReadInteger(CfgSekt,iniHgt,ClientHeight);
      end;
    DisplayMode:=TDisplayMode(ReadInteger(CfgSekt,IniDispMode,0));
    UseReg:=ReadBool(CfgSekt,IniRegional,false);
    UnpProg:=ReadString(CfgSekt,iniUnp,'');
//    UseFilelist:=ReadBool(CfgSekt,iniFileList,false);
    Free;
    end;
  LoadHistory(Ininame,FilterSekt,'',cbFilter.Items,mList);
  with cbFilter do begin
    if Items.Count=0 then AddItem('*.*',nil);
    ItemIndex:=0;
    end;
  if not sf.IsEmpty then AddToHistory(cbFilter,sf);
  LoadHistory(Ininame,FileSekt,iniFName,cbFile.Items,mList);
  with cbFile do begin
    with Items do for i:=Count-1 downto 0 do
      if not FileExists(Strings[i]) then Delete(i);
    if Items.Count>0 then ItemIndex:=0;
    end;
  AddToHistory(cbFile,sa);
  LoadHistory(Ininame,DirSekt,iniFName,cbDir.Items,mList);
  with cbDir do if Items.Count>0 then ItemIndex:=0;
  if not sd.IsEmpty then AddToHistory(cbDir,sd);
  pnExtract.Visible:=false; NewUnp:=true; CanList:=false;
  Caption:=ProgVersName+' - '+_('Inspect and unpack InnoSetup files');
  ConsoleText:=TStringList.Create;
  SelectedFiles:=TStringList.Create;
  with pbShowText do Canvas.Font:=Font;
  LineHeight:=MulDiv(abs(pbShowText.Font.Height),12,10);
  TempFile:=TempDirectory+'FileList.txt';
  SelFilesHint:='==> '+_('Selected files');
  ViewMode:=vmNone;
  if UseReg then pmiLocalized.Checked:=true
  else pmiInternational.Checked:=true;
// set style for Windows dark mode
  SetDefaultStyles(DarkStyle);
  if UseDarkMode then SelectStyle(true)
  else ChangeStyle(DisplayMode);
  pmiDisplay.Items[integer(DisplayMode)].Checked:=true;
  end;

procedure TMainForm.FormDestroy(Sender: TObject);
begin
  if FileExists(TempFile) then DeleteFile(TempFile);
  ConsoleText.Free; SelectedFiles.Free; Languages.Free;
  end;

procedure TMainForm.FormMouseWheel(Sender: TObject; Shift: TShiftState;
  WheelDelta: Integer; MousePos: TPoint; var Handled: Boolean);
begin
with pbShowText do if sbVert.Visible and ClientRect.Contains(ScreenToClient(MousePos)) then begin
    if WheelDelta<>0 then with sbVert do begin
      if WheelDelta<0 then begin
        if Position<Max then Position:=Position+1
        end
      else begin
        if Position>Min then Position:=Position-1;
        end;
      end;
    pbShowText.Invalidate;
    Handled:=true;
    end;
  end;

procedure TMainForm.FormShow(Sender: TObject);
begin
  Left:=mp.Left;
  Top:=mp.Top;
  ClientWidth:=mp.Width;
  ClientHeight:=mp.Height;
  with bbInfo do begin
    Glyph:=nil;
    ilStat.GetBitmap(integer(StylesEnabled),Glyph);
    end;
  if not FileExists(UnpProg) then UnpProg:=SetDirName(PrgPath)+InnoUnp;
  if not FileExists(UnpProg) then begin
    if not LoadUnpacker then Close;
    end;
  CheckUnpackVersion;
  if FileExists(cbFile.Text) then bbSetupInfoClick(Sender)
  else bbFileClick(Sender);
  end;

procedure TMainForm.FormResize(Sender: TObject);
begin
  if Visible then begin
    if TextWdt>0 then begin
      sbHorz.Visible:=TextWdt>pbShowText.Width;
      with sbHorz do if Visible then Max:=TextWdt-pbShowText.Width;
      end;
    if ConsoleText.Count>0 then begin
      VisibleLines:=pbShowText.Height div LineHeight;
      sbVert.Visible:=ConsoleText.Count>VisibleLines;
      with sbVert do if Visible then begin
        Max:=ConsoleText.Count-VisibleLines;
        if Position>Max then Position:=Max;
        end;
      pbShowText.Invalidate;
      end;
    end;
  end;

procedure TMainForm.FormClose(Sender: TObject; var Action: TCloseAction);
begin
  with TUnicodeIniFile.CreateForWrite(IniName) do begin
    EraseSectionValues(CfgSekt);
    WriteInteger(CfgSekt,iniLeft,Left);
    WriteInteger(CfgSekt,iniTop,Top);
    WriteInteger(CfgSekt,IniDispMode,integer(DisplayMode));
    WriteBool(CfgSekt,IniRegional,UseReg);
    WriteInteger(CfgSekt,iniWdt,ClientWidth);
    WriteInteger(CfgSekt,iniHgt,ClientHeight);
    WriteString(CfgSekt,iniUnp,UnpProg);
    Free;
    end;
  SaveHistory(Ininame,FilterSekt,'',true,cbFilter.Items,mList);
  SaveHistory(Ininame,FileSekt,iniFName,true,cbFile.Items,mList);
  SaveHistory(Ininame,DirSekt,iniFName,true,cbDir.Items,mList);
  end;

procedure TMainForm.SetLanguageClick(Sender : TObject; const Language : TLangCodeString);
var
  sl : TLangCodeString;
begin
  if not AnsiSameStr(SelectedLanguage,Language) then begin
    sl:=ChangeLanguage(Language);
    Languages.LoadLanguageNames(sl);
    Caption:=ProgVersName+' - '+_('Inspect and unpack InnoSetup files');
    UpdateView;
    end;
  end;

procedure TMainForm.CheckUnpackVersion;
var
  uv : TVersion;
  vi : TFileVersionInfo;
begin
  NewUnp:=false; CanList:=false;
  if GetFileVersion(UnpProg,vi) then with vi do begin
    UnpVersion:=ProductName+Space+_('Version')+Space+Version;
    uv:=FileVersionToNumber(vi.Version); //GetFileVersionAsNumber(UnpProg,UnpVers);
    with uv do begin
      NewUnp:=(Major>1) or ((Major>=1) and (Minor>=70));
      CanList:=(Major>=2) and ((Minor>=66) or (Minor=65) and (Release>=4));
      end;
    end
  else UnpVersion:=_('Unknown unpacker');
  end;

function TMainForm.IsUnicodeSetup : boolean;
begin
  with ConsoleText do if Count>0 then Result:=AnsiContainsText(Text,'(Unicode)')
  else Result:=false;
  end;

procedure TMainForm.bbExitClick(Sender: TObject);
begin
  RemoveFromHistory(cbFilter.Items,SelFilesHint);
  Close;
  end;

procedure TMainForm.WMDROPFILES (var Msg: TMessage);
var
   n,size: integer;
   Filename: PChar;
begin
  inherited;
  Filename:=nil;
  n:= DragQueryFile(Msg.WParam, $FFFFFFFF, Filename, 255);
  if n>0 then begin
    size := DragQueryFile(Msg.WParam, 0 , nil, 0) + 1;
    Filename:= StrAlloc(size);
    DragQueryFile(Msg.WParam,0 , Filename, size);
    if AnsiSameText(GetExt(Filename),'exe') then begin
      AddToHistory(cbFile,Filename);
      cbFile.Text:=Filename;
      Application.BringToFront;
      bbSetupInfoClick(self);
      end
    else ErrorDialog(_('This application only allows dropping of exe files!'));
    StrDispose(Filename);
  end;
  DragFinish(Msg.WParam);
end;

procedure TMainForm.sbVertScroll(Sender: TObject; ScrollCode: TScrollCode;
  var ScrollPos: Integer);
begin
  pbShowText.Invalidate;
  end;

{ ------------------------------------------------------------------- }
function TMainForm.LoadUnpacker : boolean;
begin
  with OpenDialog do begin
    if length(UnpProg)>0 then InitialDir:=ExtractFilePath(UnpProg)
    else InitialDir:=ProgPath;
    Filename:=ExtractFilename(UnpProg);
    Filter:=_('Programs|*.exe|All files|*.*');
    Title:=_('Search for "innounp.exe"');
    Result:=Execute;
    if Result then begin
      UnpProg:=Filename;
      CheckUnpackVersion;
      end;
    end;
  end;

{ ------------------------------------------------------------------- }
procedure TMainForm.cbFileCloseUp(Sender: TObject);
begin
  with cbFile do begin
    AddToHistory(Items,Items[ItemIndex],mList);
    ItemIndex:=0;
    bbSetupInfoClick(Sender);
    end;
  end;

procedure TMainForm.cbFilterCloseUp(Sender: TObject);
begin
  with cbFilter do begin
    AddToHistory(Items,Items[ItemIndex],mList);
    ItemIndex:=0;
    end;
  end;

procedure TMainForm.bbFileClick(Sender: TObject);
begin
  with OpenDialog do begin
    if length(cbFile.Text)>0 then InitialDir:=ExtractFilePath(cbFile.Text)
    else InitialDir:=UserPath;
    Filename:='';
    Filter:=_('Programs|*.exe|All files|*.*');
    Title:=_('Select InnoSetup archive');
    if Execute then begin
      AddToHistory(cbFile,Filename);
      bbSetupInfoClick(Sender);
      end;
    end;
  end;

procedure TMainForm.cbDirCloseUp(Sender: TObject);
begin
  with cbDir do begin
    AddToHistory(Items,Items[ItemIndex],mList);
    ItemIndex:=0;
    end;
  end;

procedure TMainForm.cbDirExit(Sender: TObject);
begin
  with cbDir do begin
    AddToHistory(Items,Text,mList);
    ItemIndex:=0;
    end;
  end;

procedure TMainForm.cxEmbeddedClick(Sender: TObject);
begin
  if ViewMode=vmList then bbListClick(Sender);
  end;

procedure TMainForm.cxEncryptedClick(Sender: TObject);
begin
  edPassword.Visible:=cxEncrypted.Checked;
  end;

procedure TMainForm.edPasswordKeyDown(Sender: TObject; var Key: Word;
  Shift: TShiftState);
begin
  if Key=VK_RETURN then bbVerifyClick(Sender);
  end;

procedure TMainForm.bbCopyPathClick(Sender: TObject);
begin
  AddToHistory(cbDir,DelExt(cbFile.Text));
  end;

function TMainForm.StripColCtrls (const AText : string) : string;
var
  n0,n1,n2 : integer;
begin
  Result:=''; n0:=1;
  repeat
    n1:=PosEx('<',AText,n0);
    if n1>0 then begin
      Result:=Result+copy(AText,n0,n1-n0);
      n2:=PosEx('>',AText,n1+1);
      if (n2=n1+2) then n0:=n2+1;
      end;
    until n1=0;
  Result:=Result+copy(AText,n0,length(AText)-n0+1);
  end;

procedure TMainForm.bbCopyResultClick(Sender: TObject);
begin
  ClipBoard.AsText:=_('Filename: ')+cbFile.Text+sLineBreak+sLineBreak+StripColCtrls(ConsoleText.Text);
  end;

procedure TMainForm.bbDirClick(Sender: TObject);
var
  s : string;
begin
  s:=cbDir.Text;
  if length(s)=0 then s:=ExtractFilePath(cbFile.Text);
  if ShellDirDialog.Execute(_('Select directory for extracted files'),
                true,true,false,UserPath,s) then begin
    AddToHistory(cbDir,s);
    end;
  end;

procedure TMainForm.bbInfoClick(Sender: TObject);
begin
  with BottomRightPos(Sender as TControl) do pmMain.Popup(x,y);
  end;

procedure TMainForm.bbExtractClick(Sender: TObject);
begin
  ViewMode:=vmExtract;
  with pnExtract do Visible:=not Visible;
  end;

procedure TMainForm.bbListClick(Sender: TObject);
var
  s : string;
begin
  if Visible then begin
    ViewMode:=vmList;
    pnExtract.Visible:=false;
    s:=' -v -b -h';
    if cxEmbedded.Checked then s:=s+' -m';
    if cxEncrypted.Checked then s:=s+' -p'+edPassword.Text;
    ShowUnpackInfo(s,cbFile.Text,'','');
    end;
  end;

procedure TMainForm.bbVerifyClick(Sender: TObject);
var
  s : string;
begin
  ViewMode:=vmVerify;
  pnExtract.Visible:=false;
  s:=' -b -t -h';
  if cxEmbedded.Checked then s:=s+' -m';
  if cxEncrypted.Checked then s:=s+' -p'+edPassword.Text;
  ShowUnpackInfo(s,cbFile.Text,'','',true);
  end;

procedure TMainForm.bbLangClick(Sender: TObject);
begin
  ViewMode:=vmLang;
  ShowUnpackInfo(' -l -h',cbFile.Text,'','');
  end;

procedure TMainForm.bbVersionClick(Sender: TObject);
begin
  ViewMode:=vmVersion;
  ShowUnpackInfo(' -i','','','');
  end;

procedure TMainForm.bbSetupInfoClick(Sender: TObject);
begin
  ViewMode:=vmInfo;
  ShowUnpackInfo(' -h',cbFile.Text,'','');
  UseFilelist:=false;
  cbFilter.Hint:='';
  RemoveFromHistory(cbFilter.Items,SelFilesHint);
  AddToHistory(cbFilter,'*.*');
  with rgEncoding do begin
    Visible:=not IsUnicodeSetup;
    if not Enabled then ItemIndex:=1;
    end;
  end;

procedure TMainForm.bbOptionsClick(Sender: TObject);
begin
  if LoadUnpacker then bbSetupInfoClick(Sender);
  end;

procedure TMainForm.bbScriptClick(Sender: TObject);
begin
  if UseFileList then RemoveFromHistory(cbFilter,SelFilesHint);
  UseFileList:=false;
  AddToHistory(cbFilter,'install_script.iss');
  end;

procedure TMainForm.bbFilterClick(Sender: TObject);
var
  s  : string;
  ml : TStringList;
begin
  s:='';
  if UseFileList then RemoveFromHistory(cbFilter,SelFilesHint);
  UseFileList:=false;
  ml:=TStringList.Create;
  with ml do begin
    Delimiter:=';';
    DelimitedText:=cbFilter.Text;
    end;
  if SelectFromListDialog.Execute(BottomRightPos(bbFilter,5,5),
              ExtractFileName(cbFile.Text),_('Extract files matching:'),'',
              [soEdit,soOrder],0,tcLower,'*.*',ml,s)=mrOK then
      AddToHistory(cbFilter,ml.DelimitedText);
  ml.Free;
  end;

// Select files to be extracted
procedure TMainForm.bbSelFilesClick(Sender: TObject);
var
  s : string;
  i : integer;
begin
  if not CanList then begin
    ErrorDialog(_('To use this feature at least version 2.65.4 of "innounp" is required!'));
    Exit;
    end;
  if not UseFilelist then begin
    SelectedFiles.Clear;
    s:=MakeQuotedStr(UnpProg)+' -s -b';
    if NewUnp then s:=s+' -u';
    if UseReg then s:=s+' -r';
    if cxEmbedded.Checked then s:=s+' -m';
    if cxEncrypted.Checked then s:=s+' -p'+edPassword.Text;
    s:=s+Space+MakeQuotedStr(Erweiter(PrgPath,cbFile.Text,''));
    if Execute(s,SelectedFiles) then begin
      with SelectedFiles do for i:=Count-1 downto 0 do begin
        s:=Strings[i];
        if StartsStr('  ',s) then Strings[i]:=Trim(s)
        else Delete(i);
        end;
      end
    else begin
      ErrorDialog(_('Error: ')+SysErrorMessage(GetLastError)); Exit;
      end;
    end;
  if SelectListItemsDialog.Execute(TopRightPos(bbSelFiles),ExtractFileName(cbFile.Text),'',
      _('Select files to be extracted'),SelectedFiles) then begin
    with TStringList.Create do begin
      for i:=0 to SelectedFiles.Count-1 do begin
        if integer(SelectedFiles.Objects[i]) and 1 <>0 then Add(SelectedFiles.Strings[i]);
        end;
      SaveToFile(TempFile);
      cbFilter.Hint:=Text;
      Free;
      end;
    AddToHistory(cbFilter,SelFilesHint);
    UseFilelist:=true;
    end;
  end;

procedure TMainForm.bbStartClick(Sender: TObject);
begin
  if UseFilelist then ExtractFiles(AnsiQuotedStr('@'+TempFile,'"'))
  else ExtractFiles(cbFilter.Text);
  end;

procedure TMainForm.ExtractFiles (const Filter : string);
var
  s,sd,sf,cmd : string;
begin
  sd:=cbDir.Text;
  if not ContainsFullPath(sd) then begin
    cmd:=ExtractFilePath(cbFile.Text);
    if length(cmd)=0 then cmd:=PrgPath;
    sd:=MakeQuotedStr(cmd)+sd;
    end
  else sd:=MakeQuotedStr(sd);
  s:=Filter; sf:='';
  repeat
    sf:=sf+MakeQuotedStr(ReadNxtStr(s,';'))+Space;
    until (length(s)=0);
  sf:=Trim(sf);
  if AnsiSameText(sf,'*.*') then sf:='';
  cmd:=' -b -h';
  if cxStrip.Checked then cmd:=cmd+' -e' else cmd:=cmd+' -x';
  if cxOnlyApp.Checked then cmd:=cmd+' -c{app}';
  if cxEmbedded.Checked then cmd:=cmd+' -m';
  if cxEncrypted.Checked then cmd:=cmd+' -p'+edPassword.Text;
  if cxOverwrite.Checked then cmd:=cmd+' -y';
  if rgEncoding.ItemIndex=0 then cmd:=cmd+' -w';
  if cxDupl.Checked then cmd:=cmd+' -a';
  ShowUnpackInfo(cmd+' -d'+sd,cbFile.Text,sf,'<0>*** '+_('Extract files from setup ...')+sLineBreak
    +_('Destination directory: ')+'<2>'+sd,true);
  end;

procedure TMainForm.bbUpClick(Sender: TObject);
begin
  with sbVert do Position:=Min;
  pbShowText.Invalidate;
  end;

procedure TMainForm.bbDownClick(Sender: TObject);
begin
  with sbVert do Position:=Max;
  pbShowText.Invalidate;
  end;

procedure TMainForm.ChangeStyle (dm : TDisplayMode);
begin
  DisplayMode:=dm;
  pmiDisplay.Items[integer(DisplayMode)].Checked:=true;
  SetDisplayMode(DisplayMode);
  end;

procedure TMainForm.pmiDmDarkClick(Sender: TObject);
begin
  ChangeStyle(dmDark);
  end;

procedure TMainForm.pmiDmDefaultClick(Sender: TObject);
begin
  ChangeStyle(dmDefault);
  end;

procedure TMainForm.pmiDmLightClick(Sender: TObject);
begin
  ChangeStyle(dmLight);
  end;

procedure TMainForm.UpdateView;
begin
  if UseReg then pmiLocalized.Checked:=true
  else pmiInternational.Checked:=true;
  case ViewMode of
  vmList : bbList.Click;
  vmLang : bbLang.Click;
  vmVersion : bbVersion.Click;
//  vmVerify,vmExtract
  else bbSetupInfo.Click;
    end;
  end;

procedure TMainForm.pmiInternationalClick(Sender: TObject);
begin
  UseReg:=false;
  UpdateView;
  end;

procedure TMainForm.pmiLocalizedClick(Sender: TObject);
begin
  UseReg:=true;
  UpdateView;
  end;

procedure TMainForm.pmiInfoClick(Sender: TObject);
begin
  InfoDialog (ProgVersName+' - '+ProgVersDate
    +sLineBreak+_('Inspect and unpack InnoSetup files')
    +sLineBreak+VersInfo.CopyRight
    +sLineBreak+_('e-mail: ')+EmailAdr+sLineBreak+sLineBreak+rsInfo
    +sLineBreak+sLineBreak+_('Using: ')+UnpVersion);
  end;

{ ------------------------------------------------------------------- }
// To display colors and all unicode characters, TPaintBox is used.
// It replaces a TRichEdit component because this does not support
// all Unicode characters, e.g. nepali and some chinese
procedure TMainForm.pbShowTextPaint(Sender: TObject);
var
  i,n,n0,n1,n2,w,k,d : integer;
  s,sw : string;
  bg : TColor;
const
  MaxCol = 5;
  ColArray : array[0..MaxCol] of TColor = (clBlack,clRed,clGreen,clBlue,clMaroon,clPurple);
  ColArrayDark : array[0..MaxCol] of TColor = (clWhite,TColors.Tomato,TColors.LightGreen,
      clSkyblue,TColors.Peru,TColors.Orchid);
begin
  with pbShowText do begin
    bg:=GetColor(scButtonFocused,TColors.Aliceblue);
    with Canvas.Brush do if sbVert.Position<CtHd then Color:=GetColor(scListView,clWhite)
    else Color:=bg;
    Canvas.FillRect(Rect(0,0,Width-1,Height-1));
    with ConsoleText do if Count<VisibleLines then n:=Count else n:=VisibleLines;
    d:=LineHeight div 3;
    for i:=0 to n-1 do begin
      k:=sbVert.Position+i;
      if (k=CtHd+1) then begin
        Canvas.Brush.Color:=bg;
        Canvas.FillRect(Rect(0,LineHeight*i,Width-1,Height-1));
        end
      else if Ready and (k=ConsoleText.Count-2) then begin
        Canvas.Brush.Color:=GetColor(scListView,clWhite);
        Canvas.FillRect(Rect(0,LineHeight*i,Width-1,Height-1));
        end;
      if k<ConsoleText.Count then s:=ConsoleText[k] else s:='';
      n0:=1; w:=d-sbHorz.Position;
      with Canvas.Font do begin
        if StylesEnabled then Color:=ColArrayDark[0]
        else Color:=ColArray[0];
        end;
      repeat
        n1:=PosEx('<',s,n0);
        if n1>0 then begin
          sw:=copy(s,n0,n1-n0);
          Canvas.TextOut(w,d+LineHeight*i,sw);
          w:=w+Canvas.TextWidth(sw);
          n2:=PosEx('>',s,n1+1);
          if (n2=n1+2) and TryStrToInt(copy(s,n1+1,1),k) and (k<=MaxCol) then begin
            with Canvas.Font do if StylesEnabled then Color:=ColArrayDark[k]
            else Color:=ColArray[k];
            n0:=n2+1;
            end
          else begin
            if n2=0 then n2:=n1;
            n0:=n2+1;
            end;
          end
        until n1=0;
      Canvas.TextOut(w,d+LineHeight*i,copy(s,n0,length(s)-n0+1));
      end;
    end;
  end;

{ ------------------------------------------------------------------- }
procedure TMainForm.UpdateShowText (GoBottom : boolean);

  function GetMaxTextWidth (AList : TStrings) : integer;
  var
    i : integer;
  begin
    Result:=0;
    with AList do for i:=0 to Count-1 do begin
      Result:=Max(Result,pbShowText.Canvas.TextWidth(StripColCtrls(Strings[i])));
      end;
    end;

begin
  // Show console output
  TextWdt:=GetMaxTextWidth(ConsoleText);
  with sbHorz do begin
    Visible:=TextWdt>pbShowText.Width;
    if Visible then Max:=TextWdt-pbShowText.Width;
    LargeChange:=TextWdt div 2;
    end;
  VisibleLines:=pbShowText.Height div LineHeight;
  sbVert.Visible:=ConsoleText.Count>VisibleLines;
  with sbVert do begin
    if Visible then Max:=ConsoleText.Count-VisibleLines else Max:=0;
    if GoBottom then Position:=Max else Position:=Min;
    LargeChange:=VisibleLines div 2;
    end;
  sbHorz.Position:=0;
  pbShowText.Invalidate;
  end;

procedure TMainForm.ShowUnpackInfo (const Command,FileName,Filter,Comment : string; GoBottom : boolean);
const
  TextAlign = 30;
var
  s           : string;
  dt          : TDateTime;
  vi          : TFileVersionInfo;

  function AddColString (const Text1,Text2 : string) : string;
  begin
    Result:='<0>'+ExtSp(Text1,TextAlign)+'<2>'+Text2;
    end;

  function DateString (dt : TDateTime) : string;
  begin
    if UseReg then Result:=DateToStr(dt)
    else Result:=FormatDateTime('yyyy-mm-dd',dt);
    end;

begin
  ConsoleText.Clear;
  UpdateShowText(GoBottom);
  if (length(Filename)>0) and not FileExists(FileName) then begin
    s:=SysErrorMessage(ERROR_FILE_NOT_FOUND);
    ErrorDialog(Filename+': '+s);
    Exit;
    end;
  s:=MakeQuotedStr(UnpProg)+Command;
  if NewUnp then s:=s+' -u -z';
  if UseReg then s:=s+' -r';
  if length(Filename)>0 then begin
    s:=s+Space+MakeQuotedStr(Erweiter(PrgPath,Filename,''));
    FileAge(Filename,dt);
    with ConsoleText do begin
      if GetFileVersion (Filename,vi) then begin
        Add(AddColString(_('Name: '),vi.Description));
        Add(AddColString(_('Version: '),vi.Version));
        Add(AddColString(_('Date: '),DateString(dt)));
        Add(AddColString(_('Copyright: '),Trim(vi.Copyright)));
        Add(AddColString(_('Company: '),vi.Company));
        Add(AddColString(_('Comment: '),vi.Comments));
        end;
      if length(Comment)>0 then begin
        Add('');
        Text:=Text+Comment;
        end;
      end;
    end;
  CtHd:=ConsoleText.Count;
  UpdateShowText(GoBottom);
  if length(Filter)>0 then s:=s+Space+Filter;
  Application.ProcessMessages;
  if Execute(s) then begin
    ConsoleText.Add('');
    UpdateShowText(GoBottom);
    end
  else ErrorDialog(_('Error: ')+SysErrorMessage(GetLastError));
  Application.ProcessMessages;
  end;

function TMainForm.Execute (const Command : string; OutText: TStringList) : boolean;
const
  BUFSIZE = 4096;
  defTimeOut  = 1000;  // 1 s
var
  si        : TStartupInfo;
  pi        : TProcessInformation;
  saAttr    : TSecurityAttributes;
  hChildStdoutRd,
  hChildStdoutWr  : THandle;
  chBuf           : array [0..BUFSIZE] of AnsiChar;
  dwRead,ec,wc    : DWord;
  cancel      : boolean;
  s,sc        : string;
  tc          : integer;

  function ReadPipe : string;
  var
    sa          : RawByteString;
  begin
    Result:='';
    while ReadFile(hChildStdoutRd,chBuf[0],BUFSIZE,dwRead,nil)
          and (dwRead=BUFSIZE) do begin
      sa:=sa+chBuf;
      end;
    if dwRead>0 then begin
      chBuf[dwread]:=#0;
      sa:=sa+chBuf;
      end;
    if length(sa)>0 then begin
      Result:=UTF8ToString(sa);
      Result:=ReplaceStr(Result,CrLf,Lf); // Convert Unix style output
      Result:=ReplaceStr(Result,Lf,CrLf);
      end;
    end;

begin
  Screen.Cursor:=crHourglass; Result:=false;
// Set the bInheritHandle flag so pipe handles are inherited.
  with saAttr do begin
    nLength:=sizeof(SECURITY_ATTRIBUTES);
    bInheritHandle:=TRUE;
    lpSecurityDescriptor:=nil;
    end;
// Create a pipe for the child process's STDOUT.
  CreatePipe(hChildStdoutRd,hChildStdoutWr,@saAttr,defPipeSize);
  SetHandleInformation(hChildStdoutRd, HANDLE_FLAG_INHERIT,0);
// Create process to start compiler
  FillChar(si, SizeOf(TStartupInfo), 0);
  with si do begin
    cb := Sizeof(TStartupInfo);
    dwFlags := STARTF_USESTDHANDLES or STARTF_USESHOWWINDOW;
    wShowWindow:=SW_HIDE;
    hStdOutput:=hChildStdoutWr;
//    hStdError:=hChildStdoutWr;
    end;
  try
     if CreateProcess(nil,               // Anwendungsname
                     pchar(Command),
                     nil,                // Security
                     nil,                // Security
                     true,               // use InheritHandles
                     NORMAL_PRIORITY_CLASS, // Priorit�t
                     nil,                   // Environment
                     nil,                   // Verzeichnis
                     si,pi) then begin
      CloseHandle(hChildStdoutWr);
      Cancel:=false; tc:=0; sc:=ConsoleText.Text; Ready:=false;
      repeat
        wc:=WaitForSingleObject(pi.hProcess,defTimeOut); // wait 1 s
        if wc<>WAIT_OBJECT_0 then begin
          s:=ReadPipe;
          if (s.IsEmpty) or assigned(OutText) then inc(tc)
          else begin
            sc:=sc+s;
            ConsoleText.Text:=sc;
            UpdateShowText(true);
            tc:=0;
            end;
          if tc>=10 then Cancel:=not ConfirmDialog(_('Timeout occured - continue anyway?'));
          Application.ProcessMessages;
          end;
        until (wc=WAIT_OBJECT_0) or Cancel;
      if Cancel then TerminateProcess(pi.hProcess,3);
      GetExitCodeProcess(pi.hProcess,ec); // exit code from called program
      CloseHandle(pi.hProcess);
// Close the write end of the pipe before reading from the
// read end of the pipe.
//      if CloseHandle(hChildStdoutWr) then begin
  // Read output from the child process, and write to parent's STDOUT.
      s:=ReadPipe;
      if assigned(OutText) then with OutText do Text:=Text+s
      else begin
        sc:=sc+s+sLineBreak;
        ConsoleText.Text:=sc;
        Ready:=true;
        pbShowText.Invalidate;
        end;
      CloseHandle(hChildStdoutRd);
      if wc<>WAIT_OBJECT_0 then sc:='*** '+_('Error: ')+SysErrorMessage(wc)
      else sc:='=> '+_('Done');
      if assigned(OutText) then OutText.Add(sc) else ConsoleText.Add(sc);
      Result:=true;
      end
  finally
    Screen.Cursor:=crDefault;
    end;
  end;

end.

